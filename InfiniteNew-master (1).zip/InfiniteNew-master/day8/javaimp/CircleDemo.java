public class CircleDemo {
    public void calc(double radius) {
        double area, circ;
        area = 3.14 * radius * radius;
        circ = 2 * 3.14 * radius;
        System.out.println("Area of Cirlce  " +area);
        System.out.println("Circumference   " +circ);
    }
    public static void main(String[] args) {
        double radius=8.7;
        CircleDemo obj = new CircleDemo();
        obj.calc(radius);
    }
}