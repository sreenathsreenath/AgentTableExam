public class Quiz8
{
    static int x;
    public static void main( String[] args )
    {
         System.out.println("X value is " +x);      
    }
}
