public class ArgsDemo {
    public static void main(String[] args) {
        String fname = args[0];
        String lname = args[1];
        System.out.println("First Name   " +fname);
        System.out.println("Last Name    " +lname);
    }
}