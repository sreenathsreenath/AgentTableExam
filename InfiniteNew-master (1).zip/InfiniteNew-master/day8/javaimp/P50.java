public class P50 {
  public static void main(String[] args) {
	boolean x=1;
        System.out.println(x);
  }
}