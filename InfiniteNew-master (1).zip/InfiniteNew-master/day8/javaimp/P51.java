public class P51 {
  public static void main(String[] args) {
	int x=true;
        System.out.println(x);
  }
}