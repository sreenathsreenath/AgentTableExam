package com.java.infinit.col;

import java.util.LinkedHashSet;
import java.util.Set;

public class LinkHSetDemo {

	public static void main(String[] args) {
		Set s = new LinkedHashSet();
		s.add("Aishwarya");
		s.add("Joel");
		s.add("MuraliKrishna");
		s.add("Neeraj");
		s.add("Sundar");
		s.add("Aishwarya");
		s.add("Joel");
		s.add("MuraliKrishna");
		s.add("Neeraj");
		s.add("Aishwarya");
		s.add("Joel");
		s.add("MuraliKrishna");
		s.add("Neeraj");
		s.add("Aishwarya");
		s.add("Joel");
		s.add("MuraliKrishna");
		s.add("Neeraj");
		s.add("Joel");
		s.add("MuraliKrishna");
		s.add("Neeraj");
		s.add("Sundar");
		s.add("Joel");
		s.add("MuraliKrishna");
		s.add("Neeraj");
		s.add("Sundar");
		s.add("Joel");
		s.add("MuraliKrishna");
		s.add("Neeraj");
		s.add("Sundar");
		s.add("Joel");
		s.add("MuraliKrishna");
		s.add("Neeraj");
		s.add("Sundar");
		for (Object ob : s) {
			System.out.println(ob);
		}
	}
}
