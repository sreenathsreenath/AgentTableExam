package com.java.infinite;

public class Prog1 {

	public static void main(String[] args) {
		String firstName,lastName;
		firstName="Harshit";
		lastName="Chaudhary";
		System.out.println("First Name  " +firstName);
		System.out.println("Last Name  " +lastName);
	}
}
