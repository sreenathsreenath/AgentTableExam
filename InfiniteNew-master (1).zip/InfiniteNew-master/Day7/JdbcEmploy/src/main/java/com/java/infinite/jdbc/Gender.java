package com.java.infinite.jdbc;

public enum Gender {
	MALE, FEMALE
}
